﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _02.Index_Of_Letters
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = File.ReadAllText("input.txt");
            var output = str.Select(c => c + " -> " + (c - 'a')).ToArray();
            File.WriteAllLines("output.txt", output);
            
        }
    }
}
