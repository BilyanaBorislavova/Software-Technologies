﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _05.A_Miner_Task
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, int> minerTask = new Dictionary<string, int>();

            string input = File.ReadAllText("input.txt");
            
            File.Delete("output.txt");
            string resource = input;

            int count = 1;
            int quantity = 0;

            while (input != "stop")
            {
                if (count % 2 == 1)
                {
                    resource = input;
                }
                else
                {
                    quantity = int.Parse(input);
                    if (minerTask.ContainsKey(resource))
                    {
                        quantity += minerTask[resource];
                        minerTask.Remove(resource);
                    }

                    minerTask.Add(resource, quantity);
                }

                count++;

                input = File.ReadAllText("input.txt");
            }

            foreach (var item in minerTask)
            {
                string print = $"({item.Key} -> {item.Value})";
                File.WriteAllText("output.txt", print);
 
            }
            
        }
    }
}
