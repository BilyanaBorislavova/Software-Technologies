﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _03.Equal_Sums
{
    class Program
    {
        static void Main(string[] args)
        {
            var numbers = File.ReadAllText("input.txt")
                .Split()
                .Select(int.Parse)
                .ToArray();

            bool isFountEqualSums = false;

            for (int i = 0; i < numbers.Length; i++)
            {
                int[] leftSide = numbers.Take(i).ToArray();
                int[] rightSide = numbers.Skip(i + 1).ToArray();

                if (leftSide.Sum() == rightSide.Sum())
                {
                    isFountEqualSums = true;
                    File.WriteAllText("output.txt", i.ToString());
                    break;
                }
            }
            if (!isFountEqualSums)
            {
                File.WriteAllText("output.txt", "no");
            }
        }
    }
}
