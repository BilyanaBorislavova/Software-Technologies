<?php

/* base.html.twig */
class __TwigTemplate_4bbe4cb00ce6f8d465c8dd6727bc2b9ec28634a7580dd9013cb65806d5629e1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_af7755b42fd20be521921c6eda9c95d65a7cdba58900664064adf708ea9314b9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_af7755b42fd20be521921c6eda9c95d65a7cdba58900664064adf708ea9314b9->enter($__internal_af7755b42fd20be521921c6eda9c95d65a7cdba58900664064adf708ea9314b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_02dca8f8fc3187f98a546a0dce7bb18ad3c9f63994a5edfa7a7c8f925b1b15ab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_02dca8f8fc3187f98a546a0dce7bb18ad3c9f63994a5edfa7a7c8f925b1b15ab->enter($__internal_02dca8f8fc3187f98a546a0dce7bb18ad3c9f63994a5edfa7a7c8f925b1b15ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 39
        echo "
<div class=\"container body-container\">
    ";
        // line 41
        $this->displayBlock('body', $context, $blocks);
        // line 48
        echo "</div>

";
        // line 50
        $this->displayBlock('footer', $context, $blocks);
        // line 57
        echo "
";
        // line 58
        $this->displayBlock('javascripts', $context, $blocks);
        // line 64
        echo "
</body>
</html>
";
        
        $__internal_af7755b42fd20be521921c6eda9c95d65a7cdba58900664064adf708ea9314b9->leave($__internal_af7755b42fd20be521921c6eda9c95d65a7cdba58900664064adf708ea9314b9_prof);

        
        $__internal_02dca8f8fc3187f98a546a0dce7bb18ad3c9f63994a5edfa7a7c8f925b1b15ab->leave($__internal_02dca8f8fc3187f98a546a0dce7bb18ad3c9f63994a5edfa7a7c8f925b1b15ab_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_fa29b7d11ffee985d78c60e0296f733a0c8a8360c68f2b4b5ba805aa01f6fa1a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fa29b7d11ffee985d78c60e0296f733a0c8a8360c68f2b4b5ba805aa01f6fa1a->enter($__internal_fa29b7d11ffee985d78c60e0296f733a0c8a8360c68f2b4b5ba805aa01f6fa1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_2c97380412266e6e2401d9cf8c7ffafe392f12ee53c3ec1deb9011d2277ac937 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2c97380412266e6e2401d9cf8c7ffafe392f12ee53c3ec1deb9011d2277ac937->enter($__internal_2c97380412266e6e2401d9cf8c7ffafe392f12ee53c3ec1deb9011d2277ac937_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Calculator";
        
        $__internal_2c97380412266e6e2401d9cf8c7ffafe392f12ee53c3ec1deb9011d2277ac937->leave($__internal_2c97380412266e6e2401d9cf8c7ffafe392f12ee53c3ec1deb9011d2277ac937_prof);

        
        $__internal_fa29b7d11ffee985d78c60e0296f733a0c8a8360c68f2b4b5ba805aa01f6fa1a->leave($__internal_fa29b7d11ffee985d78c60e0296f733a0c8a8360c68f2b4b5ba805aa01f6fa1a_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_df9031e0722422c9f3f53227ebe7e277c1020aa560e750789e566dcbb08e2bb2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_df9031e0722422c9f3f53227ebe7e277c1020aa560e750789e566dcbb08e2bb2->enter($__internal_df9031e0722422c9f3f53227ebe7e277c1020aa560e750789e566dcbb08e2bb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_91adfa3c117c723d09739b89d13c4b7920b5c1b0afebdb49a439c3c0b6539c0d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_91adfa3c117c723d09739b89d13c4b7920b5c1b0afebdb49a439c3c0b6539c0d->enter($__internal_91adfa3c117c723d09739b89d13c4b7920b5c1b0afebdb49a439c3c0b6539c0d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_91adfa3c117c723d09739b89d13c4b7920b5c1b0afebdb49a439c3c0b6539c0d->leave($__internal_91adfa3c117c723d09739b89d13c4b7920b5c1b0afebdb49a439c3c0b6539c0d_prof);

        
        $__internal_df9031e0722422c9f3f53227ebe7e277c1020aa560e750789e566dcbb08e2bb2->leave($__internal_df9031e0722422c9f3f53227ebe7e277c1020aa560e750789e566dcbb08e2bb2_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_0bab4e103c8d24db3f9305f8f66d7c2d8c57fe4ad65b000c0b73918e3ac74dde = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0bab4e103c8d24db3f9305f8f66d7c2d8c57fe4ad65b000c0b73918e3ac74dde->enter($__internal_0bab4e103c8d24db3f9305f8f66d7c2d8c57fe4ad65b000c0b73918e3ac74dde_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_14264aee2af17af4cadfd1af365bc73c9f380749eb2e71b042e967c47cb72cba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_14264aee2af17af4cadfd1af365bc73c9f380749eb2e71b042e967c47cb72cba->enter($__internal_14264aee2af17af4cadfd1af365bc73c9f380749eb2e71b042e967c47cb72cba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_14264aee2af17af4cadfd1af365bc73c9f380749eb2e71b042e967c47cb72cba->leave($__internal_14264aee2af17af4cadfd1af365bc73c9f380749eb2e71b042e967c47cb72cba_prof);

        
        $__internal_0bab4e103c8d24db3f9305f8f66d7c2d8c57fe4ad65b000c0b73918e3ac74dde->leave($__internal_0bab4e103c8d24db3f9305f8f66d7c2d8c57fe4ad65b000c0b73918e3ac74dde_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_34430b64da8663b97e96b8e70f95e04ca4ffcaef9afac6bf31bdb3f1f9c0535d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_34430b64da8663b97e96b8e70f95e04ca4ffcaef9afac6bf31bdb3f1f9c0535d->enter($__internal_34430b64da8663b97e96b8e70f95e04ca4ffcaef9afac6bf31bdb3f1f9c0535d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_3e25c5162121c852084a033b290dd2c671026f8dd3ae5821f166dce477ad20f8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3e25c5162121c852084a033b290dd2c671026f8dd3ae5821f166dce477ad20f8->enter($__internal_3e25c5162121c852084a033b290dd2c671026f8dd3ae5821f166dce477ad20f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
";
        
        $__internal_3e25c5162121c852084a033b290dd2c671026f8dd3ae5821f166dce477ad20f8->leave($__internal_3e25c5162121c852084a033b290dd2c671026f8dd3ae5821f166dce477ad20f8_prof);

        
        $__internal_34430b64da8663b97e96b8e70f95e04ca4ffcaef9afac6bf31bdb3f1f9c0535d->leave($__internal_34430b64da8663b97e96b8e70f95e04ca4ffcaef9afac6bf31bdb3f1f9c0535d_prof);

    }

    // line 41
    public function block_body($context, array $blocks = array())
    {
        $__internal_d15ce1a1195745a797437e23068ffc5cbec708f582f8802fa06be2e91fd2b3b0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d15ce1a1195745a797437e23068ffc5cbec708f582f8802fa06be2e91fd2b3b0->enter($__internal_d15ce1a1195745a797437e23068ffc5cbec708f582f8802fa06be2e91fd2b3b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_48d26272f269436b75a45f9fe88588062390f88afd27ee0e843e991cb68077e4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48d26272f269436b75a45f9fe88588062390f88afd27ee0e843e991cb68077e4->enter($__internal_48d26272f269436b75a45f9fe88588062390f88afd27ee0e843e991cb68077e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 42
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 44
        $this->displayBlock('main', $context, $blocks);
        // line 45
        echo "            </div>
        </div>
    ";
        
        $__internal_48d26272f269436b75a45f9fe88588062390f88afd27ee0e843e991cb68077e4->leave($__internal_48d26272f269436b75a45f9fe88588062390f88afd27ee0e843e991cb68077e4_prof);

        
        $__internal_d15ce1a1195745a797437e23068ffc5cbec708f582f8802fa06be2e91fd2b3b0->leave($__internal_d15ce1a1195745a797437e23068ffc5cbec708f582f8802fa06be2e91fd2b3b0_prof);

    }

    // line 44
    public function block_main($context, array $blocks = array())
    {
        $__internal_4373431cabd0724f53b555388478fe1157781204baa315cf27c669748589f83c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4373431cabd0724f53b555388478fe1157781204baa315cf27c669748589f83c->enter($__internal_4373431cabd0724f53b555388478fe1157781204baa315cf27c669748589f83c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_7deba3f8de43632c161ebac11c65c0f64160b66470dae2f005b47e7056d53d0a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7deba3f8de43632c161ebac11c65c0f64160b66470dae2f005b47e7056d53d0a->enter($__internal_7deba3f8de43632c161ebac11c65c0f64160b66470dae2f005b47e7056d53d0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_7deba3f8de43632c161ebac11c65c0f64160b66470dae2f005b47e7056d53d0a->leave($__internal_7deba3f8de43632c161ebac11c65c0f64160b66470dae2f005b47e7056d53d0a_prof);

        
        $__internal_4373431cabd0724f53b555388478fe1157781204baa315cf27c669748589f83c->leave($__internal_4373431cabd0724f53b555388478fe1157781204baa315cf27c669748589f83c_prof);

    }

    // line 50
    public function block_footer($context, array $blocks = array())
    {
        $__internal_51a732fb51ef80cc1911e024b1ef279d65dfec96af821ddbb20481f9269843e1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_51a732fb51ef80cc1911e024b1ef279d65dfec96af821ddbb20481f9269843e1->enter($__internal_51a732fb51ef80cc1911e024b1ef279d65dfec96af821ddbb20481f9269843e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_be903811ac69125cbbe8ff72d4ec3b0aaea79003f40c02c51b4acfeb4f60927a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be903811ac69125cbbe8ff72d4ec3b0aaea79003f40c02c51b4acfeb4f60927a->enter($__internal_be903811ac69125cbbe8ff72d4ec3b0aaea79003f40c02c51b4acfeb4f60927a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 51
        echo "    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
";
        
        $__internal_be903811ac69125cbbe8ff72d4ec3b0aaea79003f40c02c51b4acfeb4f60927a->leave($__internal_be903811ac69125cbbe8ff72d4ec3b0aaea79003f40c02c51b4acfeb4f60927a_prof);

        
        $__internal_51a732fb51ef80cc1911e024b1ef279d65dfec96af821ddbb20481f9269843e1->leave($__internal_51a732fb51ef80cc1911e024b1ef279d65dfec96af821ddbb20481f9269843e1_prof);

    }

    // line 58
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_d2b43567e109477ee5b191269e271fa8b78daad5cdc1f289919cfbf00d7fd7a1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d2b43567e109477ee5b191269e271fa8b78daad5cdc1f289919cfbf00d7fd7a1->enter($__internal_d2b43567e109477ee5b191269e271fa8b78daad5cdc1f289919cfbf00d7fd7a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_093362d7a036880f39e712379764a02a0a9822c10fa12f0170f037a32b6bee22 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_093362d7a036880f39e712379764a02a0a9822c10fa12f0170f037a32b6bee22->enter($__internal_093362d7a036880f39e712379764a02a0a9822c10fa12f0170f037a32b6bee22_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 59
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_093362d7a036880f39e712379764a02a0a9822c10fa12f0170f037a32b6bee22->leave($__internal_093362d7a036880f39e712379764a02a0a9822c10fa12f0170f037a32b6bee22_prof);

        
        $__internal_d2b43567e109477ee5b191269e271fa8b78daad5cdc1f289919cfbf00d7fd7a1->leave($__internal_d2b43567e109477ee5b191269e271fa8b78daad5cdc1f289919cfbf00d7fd7a1_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  279 => 62,  275 => 61,  271 => 60,  266 => 59,  257 => 58,  242 => 51,  233 => 50,  216 => 44,  204 => 45,  202 => 44,  198 => 42,  189 => 41,  166 => 26,  160 => 22,  151 => 21,  134 => 19,  122 => 14,  117 => 13,  108 => 12,  90 => 11,  77 => 64,  75 => 58,  72 => 57,  70 => 50,  66 => 48,  64 => 41,  60 => 39,  58 => 21,  53 => 19,  46 => 16,  44 => 12,  40 => 11,  33 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}Calculator{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('index') }}\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>

{% block footer %}
    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
", "base.html.twig", "C:\\Users\\Toch\\Desktop\\PHP Calculator_\\Calculator\\app\\Resources\\views\\base.html.twig");
    }
}
