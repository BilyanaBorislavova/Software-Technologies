<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_d496044effa4cc39ce51801babe801f9942ccc5fec27a124c696ada197249fa7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_123d563d9b59cd8c6b7b398494ded73121a41521e28a1a42ce50ce0a2672e76e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_123d563d9b59cd8c6b7b398494ded73121a41521e28a1a42ce50ce0a2672e76e->enter($__internal_123d563d9b59cd8c6b7b398494ded73121a41521e28a1a42ce50ce0a2672e76e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_dcfeb5d73dc144d274f500a9012684d895a53a8b030ad83c11e2b1cf89c6d78f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dcfeb5d73dc144d274f500a9012684d895a53a8b030ad83c11e2b1cf89c6d78f->enter($__internal_dcfeb5d73dc144d274f500a9012684d895a53a8b030ad83c11e2b1cf89c6d78f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_123d563d9b59cd8c6b7b398494ded73121a41521e28a1a42ce50ce0a2672e76e->leave($__internal_123d563d9b59cd8c6b7b398494ded73121a41521e28a1a42ce50ce0a2672e76e_prof);

        
        $__internal_dcfeb5d73dc144d274f500a9012684d895a53a8b030ad83c11e2b1cf89c6d78f->leave($__internal_dcfeb5d73dc144d274f500a9012684d895a53a8b030ad83c11e2b1cf89c6d78f_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_c5e10d1546de3b9954b4bd881ad30f44be56cbf36f47ebab2216dae5921c0baf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c5e10d1546de3b9954b4bd881ad30f44be56cbf36f47ebab2216dae5921c0baf->enter($__internal_c5e10d1546de3b9954b4bd881ad30f44be56cbf36f47ebab2216dae5921c0baf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_77dc24f434e58d16a00ce84e04838ce0c537634be2ffcddddd329232bfdb4e05 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_77dc24f434e58d16a00ce84e04838ce0c537634be2ffcddddd329232bfdb4e05->enter($__internal_77dc24f434e58d16a00ce84e04838ce0c537634be2ffcddddd329232bfdb4e05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_77dc24f434e58d16a00ce84e04838ce0c537634be2ffcddddd329232bfdb4e05->leave($__internal_77dc24f434e58d16a00ce84e04838ce0c537634be2ffcddddd329232bfdb4e05_prof);

        
        $__internal_c5e10d1546de3b9954b4bd881ad30f44be56cbf36f47ebab2216dae5921c0baf->leave($__internal_c5e10d1546de3b9954b4bd881ad30f44be56cbf36f47ebab2216dae5921c0baf_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_9ed4987c41712d011ae8cab44cc1a86415f27b265099401471cc8b370b41f5b7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9ed4987c41712d011ae8cab44cc1a86415f27b265099401471cc8b370b41f5b7->enter($__internal_9ed4987c41712d011ae8cab44cc1a86415f27b265099401471cc8b370b41f5b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_4aea7f304bdc1279e4de87fc5ca3651cd7712e821f2ea54386aaffa4b84d898c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4aea7f304bdc1279e4de87fc5ca3651cd7712e821f2ea54386aaffa4b84d898c->enter($__internal_4aea7f304bdc1279e4de87fc5ca3651cd7712e821f2ea54386aaffa4b84d898c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_4aea7f304bdc1279e4de87fc5ca3651cd7712e821f2ea54386aaffa4b84d898c->leave($__internal_4aea7f304bdc1279e4de87fc5ca3651cd7712e821f2ea54386aaffa4b84d898c_prof);

        
        $__internal_9ed4987c41712d011ae8cab44cc1a86415f27b265099401471cc8b370b41f5b7->leave($__internal_9ed4987c41712d011ae8cab44cc1a86415f27b265099401471cc8b370b41f5b7_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_8906e238509325e557c3bfbd38a81190051531a2410a331157a1f8e173ec274b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8906e238509325e557c3bfbd38a81190051531a2410a331157a1f8e173ec274b->enter($__internal_8906e238509325e557c3bfbd38a81190051531a2410a331157a1f8e173ec274b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_6d78228e45e99d5f21d2d369dd18b325c9ea937f22bc8f2ac4b095bc2fcdee50 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d78228e45e99d5f21d2d369dd18b325c9ea937f22bc8f2ac4b095bc2fcdee50->enter($__internal_6d78228e45e99d5f21d2d369dd18b325c9ea937f22bc8f2ac4b095bc2fcdee50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_6d78228e45e99d5f21d2d369dd18b325c9ea937f22bc8f2ac4b095bc2fcdee50->leave($__internal_6d78228e45e99d5f21d2d369dd18b325c9ea937f22bc8f2ac4b095bc2fcdee50_prof);

        
        $__internal_8906e238509325e557c3bfbd38a81190051531a2410a331157a1f8e173ec274b->leave($__internal_8906e238509325e557c3bfbd38a81190051531a2410a331157a1f8e173ec274b_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\Users\\Toch\\Desktop\\PHP Calculator_\\Calculator\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
