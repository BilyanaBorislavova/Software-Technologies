<?php

/* @WebProfiler/Icon/validator.svg */
class __TwigTemplate_93ebe01f2b9ab89ba08c41e95a6d75eeee58cc949b966baf715b2e852e2af566 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f4dd9bb41497a35a35d56fcf53437cbb5361a3d6963506a761f7567d5d8b9730 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f4dd9bb41497a35a35d56fcf53437cbb5361a3d6963506a761f7567d5d8b9730->enter($__internal_f4dd9bb41497a35a35d56fcf53437cbb5361a3d6963506a761f7567d5d8b9730_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/validator.svg"));

        $__internal_b686e14bd08373f53cc0d49b04b56f89cb334988f01c4297612e8d19e41556ae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b686e14bd08373f53cc0d49b04b56f89cb334988f01c4297612e8d19e41556ae->enter($__internal_b686e14bd08373f53cc0d49b04b56f89cb334988f01c4297612e8d19e41556ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/validator.svg"));

        // line 1
        echo "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\"><path fill=\"#aaaaaa\" d=\"M19.54,22.5H4.29a2.88,2.88,0,0,1-2.87-2.87V4.37A2.88,2.88,0,0,1,4.29,1.5H18.54a1,1,0,0,1,0,2H4.29a.88.88,0,0,0-.87.87V19.63a.88.88,0,0,0,.87.87H19.54a.88.88,0,0,0,.87-.87V11.29a1,1,0,1,1,2,0v8.33A2.88,2.88,0,0,1,19.54,22.5ZM13,17.29,22.88,6a1.5,1.5,0,1,0-2.26-2L12,14,8,9.11A1.5,1.5,0,0,0,5.65,11l5.1,6.25a1.5,1.5,0,0,0,1.14.55h0A1.5,1.5,0,0,0,13,17.29Z\"/></svg>
";
        
        $__internal_f4dd9bb41497a35a35d56fcf53437cbb5361a3d6963506a761f7567d5d8b9730->leave($__internal_f4dd9bb41497a35a35d56fcf53437cbb5361a3d6963506a761f7567d5d8b9730_prof);

        
        $__internal_b686e14bd08373f53cc0d49b04b56f89cb334988f01c4297612e8d19e41556ae->leave($__internal_b686e14bd08373f53cc0d49b04b56f89cb334988f01c4297612e8d19e41556ae_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Icon/validator.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\"><path fill=\"#aaaaaa\" d=\"M19.54,22.5H4.29a2.88,2.88,0,0,1-2.87-2.87V4.37A2.88,2.88,0,0,1,4.29,1.5H18.54a1,1,0,0,1,0,2H4.29a.88.88,0,0,0-.87.87V19.63a.88.88,0,0,0,.87.87H19.54a.88.88,0,0,0,.87-.87V11.29a1,1,0,1,1,2,0v8.33A2.88,2.88,0,0,1,19.54,22.5ZM13,17.29,22.88,6a1.5,1.5,0,1,0-2.26-2L12,14,8,9.11A1.5,1.5,0,0,0,5.65,11l5.1,6.25a1.5,1.5,0,0,0,1.14.55h0A1.5,1.5,0,0,0,13,17.29Z\"/></svg>
", "@WebProfiler/Icon/validator.svg", "C:\\Users\\Toch\\Desktop\\PHP Calculator_\\Calculator\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Icon\\validator.svg");
    }
}
